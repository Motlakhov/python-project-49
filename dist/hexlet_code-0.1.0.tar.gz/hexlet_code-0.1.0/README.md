### Hexlet tests and linter status:
[![Actions Status](https://github.com/Motlakhov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Motlakhov/python-project-49/actions)
<a href="https://codeclimate.com/github/Motlakhov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c76c3530f13d7cb7184b/maintainability" /></a>
[![asciicast](https://asciinema.org/a/rs4CnLwZqNFDNJku7v2pz1ywc.svg)](https://asciinema.org/a/rs4CnLwZqNFDNJku7v2pz1ywc)
[![asciicast](https://asciinema.org/a/8sdqTSvScZSNNtQ4sJPrjgFB8.svg)](https://asciinema.org/a/8sdqTSvScZSNNtQ4sJPrjgFB8)
[![asciicast](https://asciinema.org/a/jgXJQ9mXxGZHMCXmsIbfAnoIU.svg)](https://asciinema.org/a/jgXJQ9mXxGZHMCXmsIbfAnoIU)
[![asciicast](https://asciinema.org/a/Fzy2TCDTcLyIe0r2RmkDhx0nE.svg)](https://asciinema.org/a/Fzy2TCDTcLyIe0r2RmkDhx0nE)
